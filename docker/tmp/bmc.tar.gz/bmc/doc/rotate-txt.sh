#!/bin/sh

awk '
{
    line = NR/2;
    n = split($0, row, "");
    for (i = 1; i <= n; i++) {
	if (text[line,i/4] != row[i]);
	    text[line,i/4] = row[i];
    }
    width = width > n/4 ? width : n/4;
}
END {
    for (k = width; k >= 1; k--) {
	for (i = 1; i <= line; i++) {
	    printf("%1s", text[i,k]);
	}
	printf("\n");
    }
}'
