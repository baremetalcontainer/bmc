#!/bin/sh

awk '
{
    text[NR] = $0;
}
END {
    for (i = 1; i <= NR; i++) {
	printf("%*s%s\n", (NR-i)/2, "", text[i]);
    }
}'
