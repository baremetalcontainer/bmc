#!/bin/sh

tph_enabled_path="/sys/kernel/mm/transparent_hugepage/enabled"
tph_enabled_on=always
tph_enabled_off=never

nr_hugepages_path="/proc/sys/vm/nr_hugepages"
nr_hugepages_on=3000
nr_hugepages_off=0

scan_sleep_millisecs_path="/sys/kernel/mm/transparent_hugepage/khugepaged/scan_sleep_millisecs"
scan_sleep_millisecs_0=0
scan_sleep_millisecs_10000=10000

set_hugepage()
{
	local bmcid="$1"; shift
	local setting="$1"; shift

	{
	case "$setting" in
	*THPon*)	echo "echo $tph_enabled_on  >$tph_enabled_path" ;;
	*THPoff*)	echo "echo $tph_enabled_off >$tph_enabled_path" ;;
	esac

	case "$setting" in
	*HTLBon*)	echo "echo $nr_hugepages_on  >$nr_hugepages_path" ;;	# NOTICE: memory exhaustion if value is too large..
	*HTLBoff*)	echo "echo $nr_hugepages_off >$nr_hugepages_path" ;;
	esac

	case "$setting" in
	*Scn0*)		echo "echo $scan_sleep_millisecs_0     >$scan_sleep_millisecs_path" ;;
	*Scn10000*)	echo "echo $scan_sleep_millisecs_10000 >$scan_sleep_millisecs_path" ;;
	esac

	echo "grep . $tph_enabled_path $nr_hugepages_path $scan_sleep_millisecs_path"
	} | "$bmc" attach "$bmcid" "/bin/sh -x"
}
