#!/bin/sh
set -ue

echo "#size target smt i gflops time joule joule/gflops"
for size in 1600 3200 6400 12800; do
	for target in pkglapack pkgblas myblas; do
		for smt in on off; do
			for i in $(seq 1 5); do
				label="blas-$size-$target-Smt$smt-$i"
				resfile="res-$label.out"
				if [ ! -f "$resfile" ]; then
					echo "*** skip $label"
					continue
				fi
				gflops=$(awk '/GFLOPS/{print $3}' $resfile)
				time=$(grep "$label" report2.out | awk -F, '$2=="time"{print $6}')
				joule=$(grep "$label" report2.out | awk -F, '$2=="pwr"{print $6}')
				jpg=$(echo "4k $joule $gflops / p" | dc)
				printf "%s %s %s %s %s %s %s %s\n" $size $target $smt $i "${gflops:-NA}" "${time:-NA}" "${joule:-NA}" "$jpg"
			done
		done
	done
done

