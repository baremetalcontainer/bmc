#!/bin/sh
set -uex

export LANG=C

BMC_CONF=/opt/bmc/etc/bmc.conf
. "$BMC_CONF"
. ../comm/meter.sh

#################### paramters

###
### programs (can be changed)
###
bmc="$BMC_BIN_DIR/bmc"
bmccopy="$BMC_TOOL_DIR/bmc-copy"
sarnet=$BMC_TOOL_DIR/sarnet
watt=$BMC_TOOL_DIR/wattchecker
mkchart=$BMC_TOOL_DIR/mkchart
joule=$BMC_TOOL_DIR/joule

###
### settings (should be changed)
###
kernel="vmlinuz-3.13.11-ckt30"
initrd="initrd.img-3.13.11-ckt30"
rootfs="java.centos7.bmc"
fstype=ramfs

#################### Trimomatic
TVER="0.35"
TRIM="Trimmomatic-$TVER"
TRIM_JAR="$TRIM/trimmomatic-$TVER.jar"
DATA_LIST="DRR000002_1.fastq.bz2 DRR000002_2.fastq.bz2"

download_files()
{
	[ -f $TRIM.zip ] || wget http://www.usadellab.org/cms/uploads/supplementary/Trimmomatic/$TRIM.zip
	for DATA in $DATA_LIST; do
		[ -f $DATA ] || wget ftp://ftp.ddbj.nig.ac.jp/ddbj_database/dra/fastq/DRA000/DRA000002/DRX000002/$DATA
	done
}

###
### worker (should be changed)
###
rank_list="1"

###
### HugePage (may be changed)
###
test_list="\
THPoff_HTLBoff_Scn10000
THPon_HTLBoff_Scn10000
THPon_HTLBon_Scn10000
THPon_HTLBoff_Scn0
"

###
### monitoring (may be changed)
###
net_settling_time=1
pwr_settling_time=10
poweroff_guard_time=10	# time after amt poweroff before circuit off.
min_power_threshold=1
power_delay=4
bmc_run_guard_time=1

###
### peripheral
###
dev_watt=/dev/ttyUSB0
#dev_watt=""		# if dev_watt is empty, wattchecker is not invoked.

. ../redis/hugepage.sh
. ../comm/parse_arg.sh
#################### end

meter_init

cleanup()
{
	meter_stop
	exit 1
}
trap cleanup INT TERM EXIT

#### main

meter_start

# pull rootfs if it is not imported/pulled, 
$bmc image-info --rootfs "$rootfs" || $bmc pull --nopull $rootfs

bench1()
{
	local bmcid="$1"; shift
	local node_rank="$1"; shift
	local setting="$1"; shift

	set_hugepage "$bmcid" "$setting"
	sleep 1	#settling time

	local i
	for i in $(seq 1 1); do
		local label="trim-Node$node_rank-$setting-$i"
		"$bmc" timestamp "$label:begin bmcid=$bmcid"
		"$bmc" attach "$bmcid" "cd /root && make run TRIM='$TRIM' TRIM_JAR='$TRIM_JAR' DATA_LIST='$DATA_LIST'" 2>&1 | tee -a res-$label.out
		"$bmc" timestamp "$label:end bmcid=$bmcid"
		meter_request_report "$bmcid" "time" "xxx" "[$label" "$label]"
		meter_request_report "$bmcid" "pwr" "xxx" "[$label" "$label]"
	done
}
bench()
{
	local node_rank bmcid test
	for node_rank in $rank_list; do
		"$bmc" run --cidfile=cid.out --rank="eq $node_rank" --fstype="$fstype" "$rootfs" "$kernel" "$initrd" true
		bmcid="$(cat cid.out)"; rm "cid.out"
		echo "$bmcid" >>bmcid_list.out

		## prepare
		for F in Makefile $TRIM.zip $DATA_LIST; do
			"$bmccopy" "$F" "$bmcid:/root/$F"
		done
		"$bmc" attach "$bmcid" "yum install -y make unzip time && cd /root && unzip -x Trimmomatic-0.35.zip"

		for test in $test_list; do
			bench1 "$bmcid" "$node_rank" "$test" 2>&1 | tee "bench-N$node_rank-T$test.log"
		done
		sleep 1	# settling time
	done

	"$bmc" kill "$bmcid"
	"$bmc" rm "$bmcid"
	sleep $poweroff_guard_time
}

download_files
bench

meter_stop
trap - EXIT
meter_make_report >./report.out

echo "FIN"
exit 0
