#!/bin/sh
set -uex

export LANG=C

BMC_CONF=/opt/bmc/etc/bmc.conf
. "$BMC_CONF"
. ../comm/meter.sh

#################### paramters

###
### programs (can be changed)
###
bmc="$BMC_BIN_DIR/bmc"
bmccopy="$BMC_TOOL_DIR/bmc-copy"
sarnet=$BMC_TOOL_DIR/sarnet
watt=$BMC_TOOL_DIR/wattchecker
mkchart=$BMC_TOOL_DIR/mkchart
joule=$BMC_TOOL_DIR/joule

###
### settings (should be changed)
###
kernel="vmlinuz-3.13.11-ckt30"
initrd="initrd.img-3.13.11-ckt30"
rootfs="apache.centos7.bmc"
fstype=ramfs


###
### RFS
###
test_list="Normal RFS"

###
### worker (should be changed)
###
rank_list="1"

###
### monitoring (may be changed)
###
net_settling_time=1
pwr_settling_time=10
poweroff_guard_time=10	# time after amt poweroff before circuit off.
min_power_threshold=1
power_delay=4
bmc_run_guard_time=1

###
### peripheral
###
dev_watt=/dev/ttyUSB0
#dev_watt=""		# if dev_watt is empty, wattchecker is not invoked.

ab="/usr/bin/ab"
repeat=5
bench_interval=60

. ../comm/parse_arg.sh
#################### end

meter_init

cleanup()
{
	meter_stop
	exit 1
}
trap cleanup INT TERM EXIT

#### main

meter_start

# pull rootfs if it is not imported/pulled, 
$bmc image-info --rootfs "$rootfs" || $bmc pull --nopull $rootfs

bench1()
{
	local bmcid="$1"; shift
	local node_rank="$1"; shift
	local setting="$1"; shift

	case "$setting" in
	*RFS*)	"$bmc" attach "$bmcid" "cd /sys/class/net/eth?/queues/rx-0 && echo f >rps_cpus && echo 32768 >rps_flow_cnt"
		"$bmc" attach "$bmcid" "echo 32768 >/proc/sys/net/core/rps_sock_flow_entries"
		;;
	*)	"$bmc" attach "$bmcid" "cd /sys/class/net/eth?/queues/rx-0 && echo 0 >rps_cpus && echo 0     >rps_flow_cnt"
		"$bmc" attach "$bmcid" "echo 0     >/proc/sys/net/core/rps_sock_flow_entries"
		;;
	esac

	local addr; addr="$("$bmc" ps --tsv | awk -v bmcid="$bmcid" '$1==bmcid{print $2}')"
	local i
	for i in $(seq 1 $repeat); do
		local label="ab-Node$node_rank-$setting-$i"
		"$bmc" timestamp "$label:begin bmcid=$bmcid"
		"$ab" -n 100000 -c 100 "http://$addr/test.txt" 2>&1 | tee res-$label.out
		#"$ab" -n 1000000 -c 100 "http://$addr/test.txt" 2>&1 | tee res-$label.out
		sleep $bench_interval
		"$bmc" timestamp "$label:end bmcid=$bmcid"
		meter_request_report "$bmcid" "time" "xxx" "[$label" "$label]"
		meter_request_report "$bmcid" "pwr" "xxx" "[$label" "$label]"
	done
}
bench()
{
	for node_rank in $rank_list; do
		"$bmc" run --cidfile=cid.out --rank="eq $node_rank" --fstype=ramfs "$rootfs" "$kernel" "$initrd" true
		local bmcid; bmcid="$(cat cid.out)"; rm "cid.out"
		echo "$bmcid" >>bmcid_list.out

		for test in $test_list; do
			bench1 "$bmcid" "$node_rank" "$test" 2>&1 | tee "bench-N$node_rank-T$test.log"
		done

		"$bmc" kill "$bmcid"
		"$bmc" rm "$bmcid"
		sleep $poweroff_guard_time
	done
}

test -x "$ab" || { echo "ERROR: $ab is not installed"; exit 1; }

bench

meter_stop
trap - EXIT
meter_make_report >./report.out

echo "FIN"
exit 0
