#!/bin/sh
set -eu

DEST="${1-}"
GCDA=sys/kernel/debug/gcov

MSG() {
  #echo "$*" >&2
  :
}

if [ ! -d "/$GCDA" ] ; then
  MSG "mount -t debugfs none /sys/kernel/debug"
  exit 1
fi

if [ -z "$DEST" ] ; then
  MSG "Usage: $0 <output.tar.gz>"
  exit 1
fi

TEMPDIR=$(mktemp -d)
MSG "Collecting data.."

#(cd / && find $GCDA -name '*.gcda' -print) | (cd / && cpio -o -H ustar) | gzip >$DEST
find /$GCDA -type d -exec mkdir -p $TEMPDIR/\{\} \;
find /$GCDA -name '*.gcda' -exec sh -c 'cat < $0 > '$TEMPDIR'/$0' {} \;
#find /$GCDA -name '*.gcno' -exec sh -c 'cp -d $0 '$TEMPDIR'/$0' {} \;
tar czf $DEST -C $TEMPDIR sys
rm -rf $TEMPDIR

MSG "$DEST successfully created, copy to build system and unpack with:"
MSG "  tar xfz $DEST"
