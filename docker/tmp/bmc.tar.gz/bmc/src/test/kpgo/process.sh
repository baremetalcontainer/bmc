#!/bin/sh
set -eu

tgz="${1-}"
calcsum="${2:-./calcsum}"
if [ -z "$tgz" -o ! -f "$tgz" ] ; then
	echo "Usage: $0 profile.tar.gz [calcsum]"
	exit 1
fi
if [ ! -x "$calcsum" ]; then
	echo "$(basename $0):error: $calcsum is not executable"
	exit 1
fi

rm -fr sys
tar xzf "$tgz"
find sys -name '*.gcda' -print >list.txt
"$calcsum" list.txt
while read F; do
	DIR="${F%/*}"
	BASE="${F##*/}"
	G="$DIR/.tmp_$BASE"
	mv "$F" "$G"
done <list.txt

rm -f list.txt
exit 0
