#!/bin/sh
set -uex

export LANG=C

BMC_CONF=/opt/bmc/etc/bmc.conf
. "$BMC_CONF"
. ../comm/meter.sh

#################### paramters

###
### programs (can be changed)
###
bmc="$BMC_BIN_DIR/bmc"
bmccopy="$BMC_TOOL_DIR/bmc-copy"
getimage="$BMC_TOOL_DIR/bmc-get-image"
sarnet=$BMC_TOOL_DIR/sarnet
watt=$BMC_TOOL_DIR/wattchecker
mkchart=$BMC_TOOL_DIR/mkchart
joule=$BMC_TOOL_DIR/joule

###
### settings (should be changed)
###
#kernel="vmlinuz-3.13.11-ckt30"
initrd="initrd.img-3.13.11-ckt30"
rootfs="kpgo.centos7.bmc"
fstype="ramfs"

repeat=3

###
### worker (should be changed)
###
node_rank="1"

###
### monitoring
###
net_settling_time=1
pwr_settling_time=10
poweroff_guard_time=10	# time after amt poweroff before circuit off.
min_power_threshold=1
power_delay=4
bmc_run_guard_time=1

dev_watt=/dev/ttyUSB0
#dev_watt=""		# if dev_watt is empty, wattchecker is not invoked.

. ../comm/parse_arg.sh
#################### end

meter_init

cleanup()
{
	meter_stop
	exit 1
}
trap cleanup INT TERM EXIT

#### main

meter_start

bench()
{
	local kernel="$1"; shift
	local initrd="$1"; shift
	local rootfs="$1"; shift

	"$bmc" run --cidfile=cid.out --rank="eq $node_rank" --fstype="$fstype" "$rootfs" "$kernel" "$initrd" true
	bmcid="$(cat cid.out)"; rm "cid.out"
	echo "$bmcid" >>bmcid_list.out
	meter_request_report "$bmcid" "time" "bootup" "[poweron" "ssh]"
	meter_request_report "$bmcid" "pwr" "bootup" "[poweron" "ssh]"

	#--begin--
	for i in $(seq 1 $repeat); do
		for nreq in 100000 200000 400000 800000; do
			local label="kpgo-Node$node_rank-$kernel-apache-$nreq-$i"
			"$bmc" timestamp "$label:begin bmcid=$bmcid"
			"$bmc" attach "$bmcid" "/usr/bin/ab -n $nreq -c 100 http://127.0.0.1/test.txt" 2>&1 | tee "res-$label.out"
			"$bmc" timestamp "$label:end bmcid=$bmcid"
			meter_request_report "$bmcid" "time" "xxx" "[$label" "$label]"
			meter_request_report "$bmcid" "pwr" "xxx" "[$label" "$label]"
			sleep 5
		done
	done
	#--end--

	#--begin--
	"$bmc" attach "$bmcid" "/usr/bin/redis-server </dev/null >/dev/null 2>&1 &"
	sleep 3
	for i in $(seq 1 $repeat); do
		for nreq in 1000000 2000000 4000000 8000000; do
			local label="kpgo-Node$node_rank-$kernel-redis-$nreq-$i"
			"$bmc" timestamp "$label:begin bmcid=$bmcid"
			"$bmc" attach "$bmcid" "/usr/bin/redis-benchmark -P 4 -t set -r 50000 -n $nreq" 2>&1 | tee "res-$label.out"
			"$bmc" timestamp "$label:end bmcid=$bmcid"
			meter_request_report "$bmcid" "time" "xxx" "[$label" "$label]"
			meter_request_report "$bmcid" "pwr" "xxx" "[$label" "$label]"
			sleep 5
		done
	done
	#--end--

	"$bmc" kill "$bmcid"
	"$bmc" rm "$bmcid"
	sleep $poweroff_guard_time
}

initrd=initrd.img-3.13.11-ckt30
rootfs=kpgo.centos7.bmc 
bench "linux.plain" "$initrd" "$rootfs"
bench "linux.kpgo.apache" "$initrd" "$rootfs"
bench "linux.kpgo.redis" "$initrd" "$rootfs"

meter_stop
trap - EXIT
meter_make_report >./report.out

echo "FIN"
exit 0
