#!/bin/sh
set -ue

repeat=2
node_rank=1

{
echo ".TS"
echo "tab( );"
echo "l l l l l l l."
echo "kernel app nreq i rps time joule"

for app in apache redis; do
	for kernel in linux.plain linux.kpgo.apache linux.kpgo.redis; do
		for nreq in 100000 200000 400000 800000  1000000 2000000 4000000 8000000; do
			for i in $(seq 1 $repeat); do
				label="kpgo-Node$node_rank-$kernel-$app-$nreq-$i"
				resfile="res-$label.out"
				if [ ! -f "$resfile" ]; then
					echo "*** skip $label" 1>&2
					continue
				fi
				case "$app" in
				apache)
					rps=$(awk '/^Requests per second:/{print $4;exit}' $resfile)
					;;
				redis)
					rps=$(awk '/requests per second$/{print $1;exit}' $resfile)
					;;
				*)
					exit 1;;
				esac
				time=$(grep "$label" report.out | awk -F, '$2=="time"{print $6}')
				joule=$(grep "$label" report.out | awk -F, '$2=="pwr"{print $6}')
				printf "%s %s %s %s %s %s %s\n" $kernel $app $nreq $i $rps $time $joule
			done
		done
	done
done

echo ".TE"
} | tbl | nroff | sed '/^$/d'
