#!/bin/sh
set -ue

meter_init()
{
	: ${BMC_TIME_FILE:?must be set}
	: ${sarnet:?must be set}
	: ${net_settling_time:?must be set}
	: ${pwr_settling_time:?must be set}
	#: ${dev_watt:?must be set}
	: ${watt:?must be set}
	: ${poweroff_guard_time:?must be set}
	: ${min_power_threshold:?must be set}
	: ${power_delay:?must be set}
	: ${mkchart:?must be set}
	: ${joule:?must be set}
}

meter_clean_pidfile()
{
	local file="$1"
	if [ -f "$file" ]; then
		local pid; pid=$(cat "$file")
		if [ "$pid" -gt 0 ]; then
			if kill -0 "$pid"; then
				printf "ERROR: "
				ps -f -p "$pid"
				exit 1
			else
				rm -f "$file"
			fi
		else
			printf "ERROR: "
			file "$file"
			exit 1
		fi
	elif [ -e "$file" ]; then
		printf "ERROR: "
		file "$file"
		exit 1
	fi
	return 0
}

meter_kill_pid()
{
	local file="$1"
	if [ -f "$file" ]; then
		local pid; pid=$(cat "$file")
		if [ "$pid" -gt 0 ]; then
			if kill -0 "$pid"; then
				kill -TERM "$pid"
			else
				echo "ERROR: pid $pid does not exist"
			fi
			rm -f "$file"
		else
			printf "ERROR: "
			file "$file"
			exit 1
		fi
	elif [ -e "$file" ]; then
		printf "ERROR: "
		file "$file"
		exit 1
	fi
	return 0
}

meter_start()
{
	cp $BMC_TIME_FILE ./time1.out

	rm -f ./bmcid_list.out
	rm -f ./report_list.out
	touch ./bmcid_list.out
	touch ./report_list.out

	if [ -n "${sarnet-}" ]; then
		meter_clean_pidfile ./sarnet.pid
		rm -f ./sarnet.out
		$sarnet >./sarnet.out &
		local pid_sarnet=$!
		sleep $net_settling_time
		kill -0 $pid_sarnet #alive?
		echo "$pid_sarnet" >./sarnet.pid
	fi
	if [ -n "${dev_watt-}" ]; then
		meter_clean_pidfile ./watt.pid
		if [ ! -c "${dev_watt}" ]; then
			#echo "ERROR: ${dev_watt} doesn't exist"
			#exit 1
			echo "WARNING: ${dev_watt} doesn't exist"
		fi
		sudo chmod o+r $dev_watt || true
		sudo stty -F $dev_watt 1200 || true
		rm -f ./watt.out
		$watt -d $dev_watt -hvaw >./watt.out &
		local pid_watt=$!
		sleep $pwr_settling_time
		kill -0 $pid_watt #alive?
		echo "$pid_watt" >./watt.pid
	fi
}

meter_stop()
{
	if [ -f ./sarnet.pid ]; then
		meter_kill_pid ./sarnet.pid
	fi
	if [ -f ./watt.pid ]; then
		if [ "$power_delay" -gt 0 ]; then
			sleep "$power_delay"
		fi
		sleep 2	# margin
		meter_kill_pid ./watt.pid
	fi

	cp $BMC_TIME_FILE ./time2.out
	sed "1,$(wc -l <./time1.out)d" ./time2.out >./time.out

	local opt_mkchart="-l ./time.out -F png"
	if [ -f ./sarnet.out ]; then
		opt_mkchart="$opt_mkchart -n ./sarnet.out"
	fi
	if [ -f ./watt.out ]; then
		opt_mkchart="$opt_mkchart -p ./watt.out -P $poweroff_guard_time -M $min_power_threshold -D $power_delay"
	fi

	$mkchart $opt_mkchart $(cat ./bmcid_list.out)
}

meter_int_begend()
{
	case "$1" in
	\[*)	echo "${1#\[}:begin";;
	\]*)	echo "${1#\]}:begin";;
	*\])	echo "${1%\]}:end";;
	*\[)	echo "${1%\[}:end";;
	*)	echo "$1";;
	esac
}
meter_interval_time()
{
	local logfile="$1"; shift
	local p1="$(meter_int_begend "$1")"; shift
	local p2="$(meter_int_begend "$1")"; shift
	awk -F'|' -v p1="$p1" -v p2="$p2" 'index($0,p1){t1=$2}; index($0,p2){t2=$2}; END{print (t1>0 && t2>0) ? (t2 - t1) : -1}' "$logfile"
}

meter_request_report()
{
	local bmcid="$1"; shift
	local category="$1"; shift
	local label="$1"; shift
	local begin="$1"; shift
	local end="$1"; shift
	echo "$bmcid $category $label $begin $end" >>./report_list.out
}
meter_make_report()
{
	local bmcid category begin end
	while read bmcid category label begin end; do
		[ -n "$bmcid" ] || continue
		[ -n "$category" ] || continue
		[ -n "$label" ] || continue
		[ -n "$begin" ] || continue
		[ -n "$end" ] || continue
		echo -n "$bmcid,$category,$label,$begin,$end "
		case "$category" in
		time)
			if [ -f "./$bmcid.log" ]; then
				printf ", %s,[s]\n" $(meter_interval_time "./$bmcid.log" "$begin" "$end")
			else
				echo " -1"
			fi
			;;
		net|pwr)
			if [ -f "$bmcid.$category.dat" ] &&
			   $joule "./$bmcid.dat" "./$bmcid.$category.dat" "$begin" "$end" | awk '/^#/{next};{printf(", %s,%s ", $1, $2)}'
			then
				echo ""
			else
				echo " -1"
			fi
			;;
		*)	continue;;
		esac
	done <./report_list.out
}
