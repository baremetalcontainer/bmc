#!/bin/sh
while [ $# -gt 0 ]; do
	case "$1" in
	*=*)	eval ${1%%=*}=\'${1#*=}\'
		shift;;
	*)	break;;
	esac
done
