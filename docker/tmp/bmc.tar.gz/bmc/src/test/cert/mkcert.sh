#!/bin/sh
#http://server-setting.info/centos/private-ca-cert.html
set -eux

MYCNF="$PWD/openssl.cnf"
OPENSSLDIR="$(openssl version -a | sed -n '/^OPENSSLDIR:/{s/^OPENSSLDIR: "//;s/"$//;p;}')"
cp "$OPENSSLDIR/openssl.cnf" "$MYCNF"

DIFF()
{
	diff -u "$1.org" "$1" || true
}


#### STEP1.1
MYCA="$PWD/CA.sh"
if [ -f "$OPENSSLDIR/misc/CA.sh" ]; then
	cp "$OPENSSLDIR/misc/CA.sh" "$MYCA"
elif [ -f "$OPENSSLDIR/misc/CA" ]; then
	cp "$OPENSSLDIR/misc/CA" "$MYCA"
else
	echo "CA.sh is not found."
	exit 1
fi

sed -i.org '
s|^CADAYS=[^#]*$|if [ -z "$CADAYS" ] ; then CADAYS="-days 1095" ; fi	|
' "$MYCA"
DIFF "$MYCA"


#### STEP1.2
sed -i.org '
s|^dir[[:blank:]]*=[^#]*|dir = ./CA	|
s|^countryName_default[[:blank:]]*=[^#]*|countryName_default = JP	|
s|^#stateOrProvinceName_default[[:blank:]]*=[^#]*|stateOrProvinceName_default = Tokyo	|
s|^localityName_default[[:blank:]]*=[^#]*|localityName_default = Shinagawa	|
s|^0\.organizationName_default[[:blank:]]*=[^#]*|0.organizationName_default = example.com	|
/^emailAddress_max/a\
emailAddress_default = webmaster@example.com
' "$MYCNF"
DIFF "$MYCNF"


#### STEP1.3
CACNF="$PWD/openssl-ca.cnf"
SRVCNF="$PWD/openssl-server.cnf"
CLNTCNF="$PWD/openssl-client.cnf"
cp "$MYCNF" "$CACNF"
cp "$MYCNF" "$SRVCNF"
cp "$MYCNF" "$CLNTCNF"


#### STEP2
#### STEP2.1
sed -i.org -r '
/^[[] usr_cert []]/,/^[[]/{s|basicConstraints=.*|basicConstraints=CA:TRUE|}
/^[[] v3_ca []]/,/^[[]/{s|^#?[[:blank:]]*nsCertType.*|nsCertType=sslCA,emailCA|}
' "$CACNF"
DIFF "$CACNF"


#### STEP2.2
CADAYS="-days 3650" SSLEAY_CONFIG="-config $CACNF" CATOP=./CA sh "$MYCA" -newca


#### STEP2.3
openssl x509 -in ./CA/cacert.pem -outform PEM -out ./CA/capem.pem


#### STEP3
#### STEP3.1
sed -i.org -r '
/^[[] usr_cert []]/,/^[[]/{
s|basicConstraints=.*|basicConstraints=CA:FALSE|
s|^#?[[:blank:]]*nsCertType.*|nsCertType=server|
}
' "$SRVCNF"
DIFF "$SRVCNF"


#### STEP3.2
DAYS="-days 3650" SSLEAY_CONFIG="-config $SRVCNF" CATOP=./CA "$MYCA" -newreq

#### STEP3.3
SSLEAY_CONFIG="-config $SRVCNF" "$MYCA" -sign

#### STEP3.4
mv ./newcert.pem ./CA/certs/www.example.com.crt

#### STEP3.5
openssl x509 -in ./CA/certs/www.example.com.crt -outform PEM -out ./CA/certs/www.example.com.pem

#### STEP3.6
openssl rsa -in ./newkey.pem -out ./CA/private/www.example.com.key

