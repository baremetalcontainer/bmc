#!/bin/sh
set -uex

export LANG=C

BMC_CONF=/opt/bmc/etc/bmc.conf
. "$BMC_CONF"
. ../comm/meter.sh

#################### paramters

###
### settings (should be changed)
###
#fstype_list="nfs ramfs s-ramfs"
fstype_list="ramfs"
kernel=vmlinuz-3.13.11-ckt30
initrd=initrd.img-3.13.11-ckt30
rootfs=hadoop-docker-ssh
#kernel_param="transparent_hugepage=never mem=6144M"
kernel_param=""
command="date"
run_timeout=100
net_settling_time=1
pwr_settling_time=10
poweroff_guard_time=10	# time after amt poweroff before circuit off.
min_power_threshold=1
power_delay=4
bmc_run_guard_time=1

###
### worker (should be changed)
###
#worker_list="LowPower NotePC DesktopPC Server"
worker_list="XPC XPC"

XPC_rank="1"
LowPower_rank="101"
NotePC_rank="102"
DesktopPC_rank="103"
Server_rank="104"

###
### peripheral
###
dev_watt=/dev/ttyUSB0
#dev_watt=""		# if dev_watt is empty, wattchecker is not invoked.

###
### programs (can be changed)
###
bmc=$BMC_BIN_DIR/bmc
killall=$BMC_TOOL_DIR/bmckillall
sarnet=$BMC_TOOL_DIR/sarnet
watt=$BMC_TOOL_DIR/wattchecker
mkchart=$BMC_TOOL_DIR/mkchart
joule=$BMC_TOOL_DIR/joule

. ../comm/parse_arg.sh
#################### end

meter_init

now=$(date "+%Y%m%d%H%M%S")
mkdir $now
rm -f curr
ln -sf $now curr
cd $now

#### util

echon()
{
	printf "%s" "$*"
}

#xkill()
#{
#	local sig=$1; shift
#	local pid=$1; shift
#	local pgid=$(ps --no-header -o pgid -p $pid)
#	#local cmd=$(ps --no-header -o cmd -p $pid)
#	if [ "$pid" = "$pgid" ]; then
#		#echo "$cmd is leader"
#		kill $sig -$pgid || true
#	else
#		#echo "$cmd is not leader"
#		kill $sig $pid || true
#	fi
#}
xkill()
{
	kill "$@" || true
}

cleanup()
{
	meter_stop
	exit 1
}
trap cleanup INT TERM EXIT


#### main

meter_start

# pull rootfs if it is not imported/pulled, 
$bmc image-info --rootfs "$rootfs" || $bmc pull --nopull $rootfs

run1()
{
	local worker=$1; shift
	local fstype=$1; shift

	eval local rank=\"\$${worker}_rank\"

	$bmc run --cidfile=./cid.out --rank="eq $rank" $kernel_param --timeout=$run_timeout --fstype=$fstype $rootfs $kernel $initrd $command
	local bmcid; bmcid=$(cat ./cid.out)
	echo "$bmcid" >>./bmcid_list.out
	{
	echo "bmcid: $bmcid"
	echo "worker: $worker"
	echo "fstype: $fstype"
	echo "kernel: $kernel"
	echo "initrd: $initrd"
	echo "rootfs: $rootfs"
	echo "kernel_param: $kernel_param"
	echo ""
	} >>./bmcid.out

	$bmc timestamp "endtest:begin bmcid=$bmcid"
	$bmc kill $bmcid
	sleep $poweroff_guard_time
	$bmc timestamp "endtest:end bmcid=$bmcid"
	$bmc rm $bmcid

	local category
	for category in time pwr net; do
		meter_request_report "$bmcid" $category bios         [poweron ]cgi-baremetal
		meter_request_report "$bmcid" $category ipxe         [cgi-baremetal load_initrd]
		meter_request_report "$bmcid" $category initrd       load_initrd[ download-etc]
		meter_request_report "$bmcid" $category initprocess  download-etc[ ssh]
		meter_request_report "$bmcid" $category poweroff     ssh[ endtest]
		meter_request_report "$bmcid" $category total        [poweron endtest]
	done
}
for fstype in $fstype_list; do
	for worker in $worker_list; do
		run1 $worker $fstype
		sleep $bmc_run_guard_time
	done
done

meter_stop
trap - EXIT
meter_make_report >./report.out

echo "FIN"
exit 0
