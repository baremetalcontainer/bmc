#!/bin/sh
set -eux
joule=/opt/bmc/tool/joule
. ../comm/meter.sh
for DIR in "$@"; do
	(cd "$DIR" && meter_make_report >report2.out)
done

