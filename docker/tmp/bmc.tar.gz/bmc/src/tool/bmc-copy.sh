#!/bin/sh
set -eu

prog="$0"

. @BMC_CONF@
bmc=$BMC_BIN_DIR/bmc

usage()
{
	echo "\
Usage: $prog BMCID:SRC_PATH HOST_DST_PATH
Usage: $prog HOST_SRC_PATH BMCID:DST_PATH
"
}

comp=""
while getopts 'h' opt; do 
	case "$opt" in
	h)	usage; exit 0;;
	*)	usage; exit 1;;
	esac
done
shift $((OPTIND - 1))

if [ $# -ne 2 ]; then
	usage; exit 1
fi
src="$1"; shift
dst="$1"; shift

(
	case "$src" in
	-)	cat;;
	*:*)	bmcid="${src%%:*}"
		path="${src#*:}"
		$bmc attach "$bmcid" "cat $path";;
	*)	cat "$src"
	esac
) | (
	case "$dst" in
	-)	cat;;
	*:*)	bmcid="${dst%%:*}"
		path="${dst#*:}"
		$bmc attach "$bmcid" "cat >'$path'";;
	*)	cat >"$dst"
	esac
)

exit 0
