#!@BMC_TOOL_DIR@/setpgid /bin/sh

export LANG=C

#assuming output of sar:
#TIME IFACE rxpck/s txpck/s rxkB/s txkB/s rxcmp/s txcmp/s rxmcst/s
#1    2     3       4       5      6

# WARNING: sar says 1kB = 1024B
# ref: https://github.com/sysstat/sysstat/blob/master/pr_stats.c#L1019 

die() {
	trap - TERM INT
	kill -TERM -$$
}
trap die TERM INT

TODAY="$(date '+%Y-%m-%d')"
sar -n DEV 1 | awk -v OFS=, -v TODAY="$TODAY" '$2=="eth0"{print TODAY " " $1, $6, $5; fflush("")}' &
wait	#xxx: workaround
	#xxx: in some shell, without bg+wait, when shell catches signal, it suspends executing handler until fg process exits.
