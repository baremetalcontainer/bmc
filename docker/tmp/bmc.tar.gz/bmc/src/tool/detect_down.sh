#!/bin/sh
# detect_down prints poweroff time.
# usage: detect_down watt.out
set -eu
watt_file="$1"; shift
awk -F, '
BEGIN { last = 0 }
/^#/ { next }
last > 0 && $4 == 0 { print $1 }
{ last = $4 }
' $watt_file
