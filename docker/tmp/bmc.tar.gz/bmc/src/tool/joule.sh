#!/bin/sh
set -eu

usage() {
	echo "Usage: $0 BMCID.dat BMCID.pwr.dat START END"
	echo "example: $0 546d3623be1c.dat 546d3623be1c.pwr.dat [exec_run ]ssh"
	echo "example: $0 546d3623be1c.dat 546d3623be1c.pwr.dat [ssh ssh]"
	echo "example: $0 546d3623be1c.dat 546d3623be1c.net.dat [ssh ssh]"
	echo "Usage: $0 PATTERN_DAT PATTERN_PWR_DAT START END BMCID..."
	echo "example: $0 %.dat %.net.dat [ssh ssh] 546d3623be1c"
}
if [ $# -lt 4 ]; then
	usage
	exit 1
fi
arg_dat="$1"; shift
arg_pwr="$1"; shift
arg_startp="$1"; shift
arg_endp="$1"; shift
if [ $# -gt 0 ]; then
	batch=true
	case "$arg_dat" in
	*%*) ;;
	*) echo "'$arg_dat' is not a pattern"; usage; exit 1;;
	esac
	case "$arg_pwr" in
	*%*) ;;
	*) echo "'$arg_pwr' is not a pattern"; usage; exit 1;;
	esac
else
	batch=false
	if [ ! -f "$arg_dat" ]; then
		echo "'$arg_dat' doesn't exist"
		exit 1
	fi
	if [ ! -f "$arg_pwr" ]; then
		echo "'$arg_dat' doesn't exist"
		exit 1
	fi
fi

get_start()
{
	local dat="$1"; shift
	local name="$1"; shift
	awk -v N="$name" '$1==N{print $2;exit}' "$dat"
}
get_end()
{
	local dat="$1"; shift
	local name="$1"; shift
	awk -v N="$name" '$1==N{print $3;exit}' "$dat"
}

joule1()
{
	local dat="$1"; shift
	local pwr="$1"; shift
	local bmcid="${1:+$1 }"; ${1+shift}

	local startp Tstart
	case "$arg_startp" in
	\[*\[) usage; exit 1;;
	\[*) startp="${arg_startp#\[}"; Tstart="$(get_start "$dat" "$startp")";;
	*\[) startp="${arg_startp%\[}"; Tstart="$(get_end "$dat" "$startp")";;
	*) usage; exit 1;;
	esac
	if [ -z "$Tstart" ]; then
		echo "ERROR: $startp not found"
		exit 1
	fi

	local endp Tend
	case "$arg_endp" in
	\]*\]) usage; exit 1;;
	\]*) endp="${arg_endp#\]}"; Tend="$(get_start "$dat" "$endp")";;
	*\]) endp="${arg_endp%\]}"; Tend="$(get_end "$dat" "$endp")";;
	*) usage; exit 1;;
	esac

	if [ -z "$Tend" ]; then
		echo "ERROR: $endp not found"
		exit 1
	fi

	awk -v Tstart="$Tstart" -v Tend="$Tend" -v bmcid="$bmcid" '
	function floor(x) {
		return int(x);
	}
	function ceil(x) {
		return int(x + 0.999999);
	}
	BEGIN {
		Tstart0 = floor(Tstart);
		Tstart1 = 1 - (Tstart - Tstart0);
		Tend0 = floor(Tend);
		Tend1 = Tend - Tend0;
	}
	/^#/ {
		for (i = 2; i <= NF; i++)
			col[i] = $i
	}
	$1 == Tstart0 {
		start_found = 1;
		for (i = 2; i <= NF; i++)
			joule[i] += $i * Tstart1;
	}
	Tstart0 < $1 && $1 < Tend0 {
		for (i = 2; i <= NF; i++)
			joule[i] += $i;
	}
	$1 == Tend0 {
		end_found = 1;
		if (!start_found) {
			print "ERROR: consumption data is short (start side)"
			exit 1
		}
		for (i = 2; i <= NF; i++) {
			joule[i] += $i * Tend1;
			name = col[i]
			if (name) {
				# subst:
				# "X/s" -> "X"
				# "X"   -> "Xs"
				if (! sub(/\/s$/, "", name))
					name = name "s"
			}
			printf("%s%s [%s] %s %s %s\n",
				bmcid, joule[i], name, Tstart, Tend, (Tend-Tstart));
		}
		exit 0;
	}
	END {
		if (!end_found) {
			print "ERROR: consumption data is short (end side)"
			exit 1
		}
		exit 0;
	}' "$pwr"
}


if "$batch"; then
	echo "#bmcid cumulative [unit] start end diff"
	while [ $# -gt 0 ]; do
		bmcid="$1"; shift
		dat="$(echo "$arg_dat" | sed "s|%|$bmcid|g")"
		pwr="$(echo "$arg_pwr" | sed "s|%|$bmcid|g")"
		joule1 "$dat" "$pwr" "$bmcid"
	done
else
	echo "#cumulative [unit] start end diff"
	joule1 "$arg_dat" "$arg_pwr"
fi
