#!/bin/sh
set -eu

prog="$0"

. @BMC_CONF@
bmc=$BMC_BIN_DIR/bmc

usage()
{
	echo "\
Usage: $prog BMCID xxx.tar.gz
example:
    $prog 480bde4a4d38 aaaa.tar.gz
    $bmc import-rootfs bbbb aaaa.tar.gz
"
}

comp=""
while getopts 'C:h' opt; do 
	case "$opt" in
	C)	comp="$OPTARG";;
	h)	usage; exit 0;;
	*)	usage; exit 1;;
	esac
done
shift $((OPTIND - 1))

if [ $# -ne 2 ]; then
	usage; exit 1
fi
bmcid="$1"; shift
output="$1"; shift

if [ -z "$comp" ]; then
	case "$output" in
	*.tar.gz)	comp="| gzip";;
	*.tar.bz2)	comp="| bzip2";;
	*.tar)		comp="";;
	*)		usage; exit 1;;
	esac
fi

tmpfile="$output.tmp"
$bmc attach $bmcid "cd / && find . -xdev -depth -print0 | cpio -o -0 -Hustar $comp" >"$tmpfile"
mv -i "$tmpfile" "$output"

exit 0
