#!/bin/sh
BMC=/opt/bmc/bin/bmc
LST1="$($BMC ps -q)"
LST2="$($BMC ps -q -a)"
[ -n "$LST1" ] && { $BMC kill $LST1; sleep 1; }
[ -n "$LST2" ] && $BMC rm $LST2
