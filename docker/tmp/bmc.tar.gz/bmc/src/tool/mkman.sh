#!/bin/sh
BMC=/opt/bmc/bin/bmc
$BMC help |
awk '/^Commands:$/{ON=1}; /^$/{ON=0}; ON&&/^ /{print $1}' |
sort |
while read CMD; do
  echo "=== $CMD ==="
  $BMC help "$CMD"
  echo ""
done
