#!/bin/sh

# Copyright(C): National Institute of Advanced Industrial Science and Technology 2016
# Authors:     
#               Hidetaka Koie <koie-hidetaka@aist.go.jp>
#               Kuniyasu Suzaki <k.suzaki@aist.go.jp>
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

set -eu

PROG="$0"
OPT_ALL="false"
OPT_LOG="/var/tmp/bmc/time.log"
OPT_PWR=""
OPT_PWR_GUARD="3"
OPT_MIN_PWR_THR="0"
OPT_PWR_DELAY="0"
OPT_NET=""
OPT_FMT="dat"

#
# Parse command line
#
USAGE() {
	echo "Usage: $PROG [-h] [-l LOGFILE] [-p POWERFILE] [-P POWER_GUARD_TIME] [-M MIN_POWER_THRESHOLD] [-D POWER_DELAY] [-n TRAFFICFILE] [-F FORMAT] BMCID..|-A"
	echo "  FORMAT ::= 'dat' | 'x11' | 'png' | 'svg'"
	echo "POWERFILE is a CSV file: \"YYYY-MM-DD HH:MM:SS,V,A,W\""
	echo "TRAFFICFILE is a CSV file: \"YYYY-MM-DD HH:MM:SS,Tx,Rx\"  #[KiB/s]"
}

UNIQ()
{
	awk '!E[$0]{print; E[$0]=1}'
}

while getopts 'hAl:p:P:M:D:n:F:' OPT; do
	case "$OPT" in
	h)	USAGE; exit 0;;
	A)	OPT_ALL="true";;
	l)	OPT_LOG="$OPTARG";;
	p)	OPT_PWR="$OPTARG";;
	P)	OPT_PWR_GUARD="$OPTARG";;
	M)	OPT_MIN_PWR_THR="$OPTARG";;
	D)	OPT_PWR_DELAY="$OPTARG";;
	n)	OPT_NET="$OPTARG";;
	F)	OPT_FMT="$OPTARG";;
	*)	USAGE; exit 1;;
	esac
done
shift $((OPTIND - 1))
if "$OPT_ALL"; then
	if [ $# -ne 0 ]; then
		USAGE
		exit 1
	fi
	BMCID_LIST="$(awk -F'|' '$4~/exec_run alloc.* bmcid=/{print $4}' "$OPT_LOG" | grep -o 'bmcid=[^ ]*' | cut -d= -f2 | UNIQ)"
	N_BMCID="$(echo "$BMCID_LIST" | wc -l)"
	echo "BMCID:"
	echo "$BMCID_LIST"
else
	if [ $# -eq 0 ]; then
		USAGE
		exit 1
	fi
	N_BMCID="$#"
	BMCID_LIST="$*"; shift $N_BMCID
fi

case "$OPT_FMT" in
dat|x11|png|svg) ;;
*) USAGE; exit 1;;
esac

TDIF_MAX=0

mkdat()
{
	local BMCID="$1"; shift

	local BMCLOG_FILE="$BMCID.log"
	if [ "$BMCLOG_FILE" = "$OPT_LOG" ]; then
		BMCLOG_FILE="/dev/null"
	fi

	#
	# Get PID_LIST by BMCID
	#
	local PID_LIST
	PID_LIST="$(grep "bmcid=$BMCID" "$OPT_LOG" | awk -F'|' '{print $3}' | sort | uniq)"
	[ -n "$PID_LIST" ] || {
		echo "$BMCID does not exist"
		exit 1
	}
	PID_LIST="$(echo "$PID_LIST" | paste -s -d ' ')"

	#
	# Generate data from LOG
	#
	awk -F'|' -v BMCLOG_FILE="$BMCLOG_FILE" -v PID_LIST="$PID_LIST" '
	BEGIN {
		npid = split(PID_LIST, pid_list, / /);
	}
	function unixdate(t, _d) {
		cmd = "date --date \"@" t "\" \"+%Y-%m-%d %H:%M:%S\""
		cmd | getline _d;
		close(cmd);
		return _d;
	}
	function chkpid(pid) {
		for (i in pid_list) {
			if (pid_list[i] == pid)
				return 1;
		}
		return 0;
	}
	function getname(str,sfx) {
		# eg: getname("foo:begin", ":begin") returns "foo".
		re = "[^ ][^ ]*" sfx
		match(str, re)
		return substr(str, RSTART, RLENGTH - length(sfx))
	}
	chkpid($3) && $4~/:begin/ {
		print >>BMCLOG_FILE
		name = getname($4, ":begin");
		t1[name] = $2;
		nlst[N++] = name;
	}
	chkpid($3) && $4~/:end/ {
		print >>BMCLOG_FILE
		name = getname($4, ":end");
		t2[name] = $2;
	}
	END {
		tmin = tmax = -1;
		for (name in t1) {
			t = t1[name];
			if (tmin < 0 || t < tmin)
				tmin = t
			if (tmax < 0 || t > tmax)
				tmax = t
		}
		for (name in t2) {
			t = t2[name];
			if (tmin < 0 || t < tmin)
				tmin = t
			if (tmax < 0 || t > tmax)
				tmax = t
		}
		printf("#Tmin %f %s\n", tmin, unixdate(tmin));
		printf("#Tmax %f %s\n", tmax, unixdate(tmax));
		printf("#Tdif %f\n", tmax - tmin);
		for (i = 0; i < N; i++) {
			name = nlst[i];
			ts = t1[name] - tmin;
			if (name in t2) {
				te = t2[name] - tmin;
				t = te - ts;
				printf("%s\t%f\t%f\t%f\n", name, ts, te, t);
			} else {
				printf("%s(failed)\t%f\t%f\t%f\n", name, ts, ts, 0);
			}
		}
	}' "$OPT_LOG" >"$BMCID.dat"

	local TMIN TMAX TDIF
	TMIN="$(awk '/^#Tmin/ {print int($2); exit}' "$BMCID.dat")"
	TMAX="$(awk '/^#Tmax/ {print int($2+0.999); exit}' "$BMCID.dat")"
	TDIF="$(awk '/^#Tdif/ {print int($2); exit}' "$BMCID.dat")"
	TDIF_MAX="$(awk -v A="$TDIF" -v B="$TDIF_MAX" 'BEGIN{ if (A > B) print A; else print B; exit }')"

	#
	# Generate power data from PWR
	#
	if [ -n "$OPT_PWR" ]; then
		awk -F, -v TMIN="$TMIN" \
			-v TMAX="$((TMAX + OPT_PWR_GUARD))" \
			-v MIN_PWR_THR="$OPT_MIN_PWR_THR" \
			-v PWR_DELAY="$OPT_PWR_DELAY" \
		'BEGIN { print "#T W" }
		/^[^0-9]/ {next}
		{
			date = $1
			gsub(/[-:]/, " ", date)
			time = mktime(date);	# mktime is GNU AWK extension
			time -= PWR_DELAY;
			if (time < 0)
				next;
			if (time < TMIN || TMAX < time)
				next;
			watt = $4;
			if (watt < MIN_PWR_THR)
				watt = 0;
			printf("%s %s\n", time - TMIN, watt)
		}' "$OPT_PWR" >"$BMCID.pwr.dat"
	fi

	#
	# Generate traffic data from NET
	#
	if [ -n "$OPT_NET" ]; then
		NET_FILE="$BMCID.net.dat"
		awk -F, -v TMIN="$TMIN" -v TMAX="$TMAX" '
		BEGIN { print "#T TxKiB/s RxKiB/s" }
		/^[^0-9]/ {next}
		{
			date = $1
			gsub(/[-:]/, " ", date)
			time = mktime(date);	# mktime is GNU AWK extension
			if (time < 0)
				next;
			if (time < TMIN || TMAX < time)
				next;
			tx = $2;
			rx = $3;
			printf("%s %s %s\n", time - TMIN, tx, rx)
		}' "$OPT_NET" >"$BMCID.net.dat"
	fi
}

CONCAT_WITH()
{
	local SEP="$1"; shift
	local R=""
	local X
	for X; do
		R="${R:+$R$SEP}$X"
	done
	echo "$R"
}
CONCAT_WITH_SUFFIX()
{
	local SFX="$1"; shift
	local R=""
	local X
	for X; do
		R="${R:+$R }$X$SFX"
	done
	echo "$R"
}
mkplot()
{
	local ALLBMCID="$(CONCAT_WITH "," $BMCID_LIST)"
	if [ "$N_BMCID" -gt 1 ]; then
		local DAT_LIST="$(CONCAT_WITH_SUFFIX ".dat" $BMCID_LIST)"
		paste -d '\n' $DAT_LIST >"$ALLBMCID.dat"
	fi

	{
		echo "set terminal $OPT_FMT"

		[ "$OPT_FMT" = "x11" ] || echo "set output '$ALLBMCID.$OPT_FMT'"
		echo "set title 'BMC $ALLBMCID'"
		echo "set key bottom left"
		echo "set xlabel 'Time[s]'"
		## echo "set ylabel 'Action'"
		echo "set grid"
		echo "set style fill solid"
		## echo "set tics out"
		echo "set xrange [-1:$((TDIF_MAX+1))]"
		## memo: using x:y:xlow:xhigh:ylow:yhigh
		if false; then
		printf 'plot "%s" using 2:(-$0):2:3:(-$0-0.4):(-$0+0.4):ytic(1) with boxxyerrorbars notitle\n' "$ALLBMCID.dat"
		else
		printf "plot"
		local SEP=""
		local I=0
		local BMCID
		for BMCID in $BMCID_LIST; do
			printf "%s " "$SEP"; SEP=","
			#printf ''%s' using using 2:(-$0*$N_BMCID-$I):2:3:(-$0*$N_BMCID-$I-0.4):(-$0*$N_BMCID-$I+0.4):ytic(1) title '%s' with boxxyerrorbars'
			printf '"%s" using 2:(-$0*%d-%d):2:3:(-$0*%d-%d-0.4):(-$0*%d-%d+0.4):ytic(1) title "%s" with boxxyerrorbars' "$BMCID.dat" $N_BMCID $I $N_BMCID $I $N_BMCID $I $BMCID
			I=$((I+1))
		done
		printf '\n'
		fi
		[ "$OPT_FMT" != "x11" ] || echo "pause mouse close"

		if [ -n "$OPT_PWR" ]; then
		#local PWR_LIST="$(CONCAT_WITH_SUFFIX ".pwr.dat" $BMCID_LIST)"
		[ "$OPT_FMT" = "x11" ] || echo "set output '$ALLBMCID.pwr.$OPT_FMT'"
		echo "set title 'Power $ALLBMCID'"
		echo "set key top right"
		echo "set xlabel 'Time[s]'"
		echo "set ylabel 'Power[W]'"
		echo "set grid"
		## echo "set tics out"
		echo "set xrange [-1:$((TDIF_MAX+1))]"
		echo "set yrange [0:]"
		printf "plot"
		local SEP=""
		local BMCID
		for BMCID in $BMCID_LIST; do
			printf "%s " "$SEP"; SEP=","
			printf "'%s' using 1:2 title '%s' with step" "$BMCID.pwr.dat" "$BMCID"
		done
		printf '\n'
		[ "$OPT_FMT" != "x11" ] || echo "pause mouse close"
		fi

		if [ -n "$OPT_NET" ]; then
		#local NET_LIST="$(CONCAT_WITH_SUFFIX ".net.dat" $BMCID_LIST)"
		[ "$OPT_FMT" = "x11" ] || echo "set output '$ALLBMCID.net.$OPT_FMT'"
		echo "set title 'Traffic $ALLBMCID'"
		echo "set key top right"
		echo "set xlabel 'Time[s]'"
		echo "set ylabel 'Traffic[KiB/s]'"
		echo "set grid"
		## echo "set tics out"
		echo "set xrange [-1:$((TDIF_MAX+1))]"
		echo "set yrange [0:]"
		printf "plot"
		local SEP=""
		local BMCID
		for BMCID in $BMCID_LIST; do
			printf "%s " "$SEP"; SEP=","
			printf "'%s' using 1:2 title '%s Tx' with step, " "$BMCID.net.dat" "$BMCID"
			printf "'%s' using 1:3 title '%s Rx' with step"   "$BMCID.net.dat" "$BMCID"
		done
		printf '\n'
		[ "$OPT_FMT" != "x11" ] || echo "pause mouse close"
		fi
	} >"$ALLBMCID.gpl"
	gnuplot "$ALLBMCID.gpl"
}

for BMCID in $BMCID_LIST; do
	mkdat "$BMCID"
done

if [ "$OPT_FMT" != "dat" ]; then
	mkplot
fi

exit 0
