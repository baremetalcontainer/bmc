#!/bin/sh
set -eu

prog="$0"

: "${BMC_CONF:=@BMC_CONF@}"
[ -r "$BMC_CONF" ] || { echo "$0: can not read $BMC_CONF" 1>&2; exit 1; }
. "${BMC_CONF}"
. "${BMC_SHARE_DIR}/bmc.func"
 
usage()
{
	echo "\
Usage: $prog
"
}

{
echo ".mode tabs"
echo ".header off"
for tbl in kernel initrd rootfs; do
for sig in "" "sig_"; do
	col="${tbl}_${sig}file"
	echo "SELECT ${col} FROM ${tbl} WHERE ${col} IS NOT NULL AND ${col} != \"\";"
done
done
} | SQL | show_table tsv | awk '/^rootfs\// { print $0; print $0 "-etc"; next}; {print}' | sort > ./list1.out

(
cd "$BMC_REPO_ROOT"
find . -type f -print
) | sed 's|^[.]/||' | sort >./list2.out

comm -23 list1.out list2.out >dangling_file.out
comm -13 list1.out list2.out >garbage_file.out

rm -f list1.out list2.out
wc -l dangling_file.out garbage_file.out

printf "Erase garbage files? "
read yn
case "$yn" in
[Yy][Ee][Ss]) ;;
*) exit 0
esac

sed "s|^|$BMC_REPO_ROOT/|" garbage_file.out | while read -r F; do
	/usr/bin/sudo rm "$F"
done

exit 0
