#!/bin/sh
set -eu
bmcid="${1:?BMCID must be specified}"

bmc attach "$bmcid" dmesg |
awk '/^[[]/{sub(/^[[]/,""); sub(/[]]/,""); gsub(/^ */,""); print}' >"dmesg.$bmcid"

gnuplot <<__END__
set title 'dmesg $bmcid'
set grid
set xlabel 'lineno'
set ylabel 'time[s]'
plot 'dmesg.$bmcid' using 0:1 notitle
pause mouse close
__END__
