/*
  gcc -pthread -o wattchecker wattchecker.c
 */
#define _GNU_SOURCE

#include <err.h>
#include <fcntl.h>
#include <limits.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>

#ifndef DEFAULT_DEV
#define DEFAULT_DEV	"/dev/ttyUSB0"
#endif

#ifndef WT128_DIR
//#define WT128_DIR	"/dev/wt128"
#define WT128_DIR	"/dev"
#endif

#define NDEV 128

int sec, print_h, print_a, print_v, print_w;
char *progname;

struct chdata {
	char ready;
	char v[4];
	char v_frac[2];
	char a[3];
	char a_frac[3];
	char w[5];
	char hz[4];
	char hz_frac[2];
	char va[5];
	char pf[5];
	char kwh[5];
	char kwh_frac[3];
	char hour[5];
	char minute[3];
} __attribute__ ((packed));

struct chinfo {
	pthread_t p;
	pthread_mutex_t l;
	struct chdata *cd[2];
	struct termios tio;
	int fd;
	char *dev;
};

static void
usage(void)
{

	fprintf(stderr, "usage: %s [-ahvw] [-d device] [-l logdir] [-s seconds]\n",
	    progname);
	exit(EXIT_FAILURE);
}

static void *
logger(void *v)
{
	struct chinfo *ci = v;
	struct chdata *cd;
	ssize_t nr;
	int i, pos;
	char buf[36], c;

	pos = 0;
	for (;;) {
		if ((nr = read(ci->fd, &c, 1)) != 1) {
			struct timespec ts;
			struct tm *t;

			clock_gettime(CLOCK_REALTIME, &ts);
			t = localtime(&ts.tv_sec);
			fprintf(stderr, "%04d/%02d/%02d ", t->tm_year + 1900,
			    t->tm_mon + 1, t->tm_mday);
			fprintf(stderr, "%02d:%02d:%02d %s read error\n", t->tm_hour,
			    t->tm_min, t->tm_sec, ci->dev);

			ts.tv_sec = 1;
			ts.tv_nsec = 0;
			nanosleep(&ts, NULL);

			continue;
		}

		if (pos < 36 && '0' <= c && c <= '9') {
			buf[pos++] = c;
			continue;
		}

		if (pos == 36 && c == 0x03) {
			pthread_mutex_lock(&ci->l);

			if (ci->cd[0]->ready) {
				cd = ci->cd[1];
				ci->cd[1] = ci->cd[0];
				ci->cd[0] = cd;
			} else
				cd = ci->cd[0];

			for (pos = 0; pos < 2; pos++)
				if (buf[pos] != '0')
					break;

			for (i = 0; pos < 3;)
				cd->v[i++] = buf[pos++];
			cd->v[i] = '\0';

			for (i = 0; pos < 4;)
				cd->v_frac[i++] = buf[pos++];
			cd->v_frac[i] = '\0';

			for (; pos < 5; pos++)
				if (buf[pos] != '0')
					break;

			for (i = 0; pos < 6;)
				cd->a[i++] = buf[pos++];
			cd->a[i] = '\0';

			for (i = 0; pos < 8;)
				cd->a_frac[i++] = buf[pos++];
			cd->a_frac[i] = '\0';

			for (; pos < 11; pos++)
				if (buf[pos] != '0')
					break;

			for (i = 0; pos < 12;)
				cd->w[i++] = buf[pos++];
			cd->w[i] = '\0';

			cd->ready = 1;

			pthread_mutex_unlock(&ci->l);
		}

		pos = 0;
	}

	return NULL;
}

static void
write_header(FILE *fp, struct chinfo *ci, int n)
{

	fprintf(fp, "\n#time");
	while (n--) {
		if (print_v)
			fprintf(fp, ",%s(V)", ci->dev);
		if (print_a)
			fprintf(fp, ",%s(A)", ci->dev);
		if (print_w)
			fprintf(fp, ",%s(W)", ci->dev);
		ci++;
	}
	fprintf(fp, "\n");
}

static void
collect_data(struct chdata *cd, struct chinfo *ci, int n)
{

	while (n--) {
		if (ci->fd == -1) {
			cd++;
			ci++;
			continue;
		}

		pthread_mutex_lock(&ci->l);

		if (ci->cd[1]->ready) {
			memcpy(cd, ci->cd[1], sizeof(struct chdata));
			ci->cd[1]->ready = 0;
		} else if (ci->cd[0]->ready) {
			memcpy(cd, ci->cd[0], sizeof(struct chdata));
			ci->cd[0]->ready = 0;
		} else
			cd->ready = 0;

		pthread_mutex_unlock(&ci->l);

		cd++;
		ci++;
	}
}

static void
write_data(FILE *fp, struct tm *t, struct chdata *cd, int n)
{

	fprintf(fp, "%04d-%02d-%02d %02d:%02d:%02d", t->tm_year + 1900, t->tm_mon + 1, t->tm_mday,
		t->tm_hour, t->tm_min, t->tm_sec);
	while (n--) {
		if (cd->ready) {
			if (print_v)
				fprintf(fp, ",%s.%s", cd->v, cd->v_frac);
			if (print_a)
				fprintf(fp, ",%s.%s", cd->a, cd->a_frac);
			if (print_w)
				fprintf(fp, ",%s", cd->w);
		} else {
			if (print_v)
				fprintf(fp, ", ");
			if (print_a)
				fprintf(fp, ", ");
			if (print_w)
				fprintf(fp, ", ");
		}
		cd++;
	}
	fprintf(fp, "\n");
}

int
main(int argc, char *argv[])
{
	struct chdata *cd;
	struct chinfo *ci;
	struct termios tio;
	struct timespec ts;
	struct tm *t;
	FILE *fp, *fp_last;
	int ch, day, i, ndev = 0;
	char *dev[NDEV];
	char *last = NULL, *last_tmp = NULL, *log = NULL, *logdir = NULL;

	progname = argv[0];

	while ((ch = getopt(argc, argv, "ad:hl:s:vw")) != -1) {
		switch (ch) {
		case 'a':
			print_a = 1;
			break;
		case 'd':
			if (ndev == NDEV) {
				err(EXIT_FAILURE, "too many devices specified");
			}
			if ((dev[ndev++] = strdup(optarg)) == NULL) {
				err(EXIT_FAILURE, "malloc(device)");
			}
			break;
		case 'h':
			print_h = 1;
			break;
		case 'l':
			logdir = optarg;
			break;
		case 's':
			sec = strtoul(optarg, NULL, 0);
			break;
		case 'v':
			print_v = 1;
			break;
		case 'w':
			print_w = 1;
			break;
		default:
			usage();
			break;
		}
	}
	argc -= optind;
	argv += optind;

	if (ndev == 0) {
		if ((dev[ndev++] = strdup(DEFAULT_DEV)) == NULL) {
			err(EXIT_FAILURE, "malloc(device)");
		}
	}

	if ((print_a | print_v | print_w) == 0)
		print_a = print_v = print_w = 1;

	if ((cd = malloc(sizeof(struct chdata) * ndev)) == NULL)
		err(EXIT_FAILURE, "malloc(cd)");

	if ((ci = malloc(sizeof(struct chinfo) * ndev)) == NULL)
		err(EXIT_FAILURE, "malloc(ci)");

	if (logdir) {
		if ((log = malloc(PATH_MAX)) == NULL)
			err(EXIT_FAILURE, "malloc(log)");

		if (asprintf(&last, "%s/last", logdir) == -1)
			err(EXIT_FAILURE, "asprintf(last)");
		if (asprintf(&last_tmp, "%s/last.tmp", logdir) == -1)
			err(EXIT_FAILURE, "asprintf(last_tmp)");
	}

#if 0
	if (chdir(WT128_DIR) == -1)
		err(EXIT_FAILURE, "chdir(\"%s\")", WT128_DIR);
#endif

	fprintf(stderr, "logdir: %s\n", logdir ? logdir : "<stdout>");
	fprintf(stderr, "data  :%s%s%s\n", (print_v) ? " Volt" : "",
	    (print_a) ? " Ampere" : "", (print_w) ? " Watt" : "");

	for (i = 0; i < ndev; i++) {
		ci[i].dev = dev[i];
		fprintf(stderr, " %s column %d", ci[i].dev,
		    2 + i * (print_v + print_a + print_w));

		if ((ci[i].fd = open(ci[i].dev, O_RDONLY, 0)) == -1) {
			fprintf(stderr, " !open()\n");
			continue;
		}

		if (tcgetattr(ci[i].fd, &ci[i].tio) == -1) {
			fprintf(stderr, " !tcgetattr()\n");
			close(ci[i].fd);
			ci[i].fd = -1;
			continue;
		}

		memset(&tio, 0, sizeof(struct termios));
		//		cfsetspeed(&tio, B1200);
		cfsetspeed(&tio, B1200);
		tio.c_iflag = IGNPAR | INPCK | ISTRIP | ICRNL;
		tio.c_cflag = CS8 | CLOCAL | CREAD;
		tio.c_cc[VMIN] = 0;
		tio.c_cc[VTIME] = 8;

		if (tcsetattr(ci[i].fd, TCSANOW, &tio) == -1) {
			fprintf(stderr, " !tcsetattr()\n");
			tcsetattr(ci[i].fd, TCSANOW, &ci[i].tio);
			close(ci[i].fd);
			ci[i].fd = -1;
			continue;
		}

		fprintf(stderr, "\n");

		if ((ci[i].cd[0] = malloc(sizeof(struct chdata))) == NULL)
			err(EXIT_FAILURE, "malloc(cd0)");
		ci[i].cd[0]->ready = 0;

		if ((ci[i].cd[1] = malloc(sizeof(struct chdata))) == NULL)
			err(EXIT_FAILURE, "malloc(cd1)");
		ci[i].cd[1]->ready = 0;

		if (pthread_mutex_init(&ci[i].l, NULL) != 0)
			errx(EXIT_FAILURE, "pthread_mutex_init()");
	}

	for (i = 0; i < ndev; i++)
		if (ci[i].fd != -1)
			pthread_create(&ci[i].p, NULL, logger, &ci[i]);

	ts.tv_sec = 2;
	ts.tv_nsec = 0;
	nanosleep(&ts, NULL);

	day = 0;
	fp = NULL;
	for (i = 0; (sec > 0) ? i < sec : 1; i++) {
		clock_gettime(CLOCK_REALTIME, &ts);
		ts.tv_sec = 0;
		ts.tv_nsec = 1000000000L - ts.tv_nsec;
		nanosleep(&ts, NULL);

		clock_gettime(CLOCK_REALTIME, &ts);
		t = localtime(&ts.tv_sec);
		if (day != t->tm_mday) {
			if (logdir) {
				if (fp != NULL)
					fclose(fp);
#if 0
				snprintf(log, PATH_MAX, "%s/%04d%02d%02d.log", logdir, t->tm_year + 1900, t->tm_mon + 1, t->tm_mday);
#else
				snprintf(log, PATH_MAX, "%s/wattchecker.log", logdir);
#endif
				if ((fp = fopen(log, "a")) == NULL)
					continue;
			} else {
				fp = stdout;
			}
			setlinebuf(fp);
			if (print_h)
				write_header(fp, ci, ndev);
			day = t->tm_mday;
		}

		collect_data(cd, ci, ndev);
		write_data(fp, t, cd, ndev);

		if (logdir) {
			if ((fp_last = fopen(last_tmp, "w")) == NULL)
				continue;
			write_data(fp_last, t, cd, ndev);
			fclose(fp_last);
			rename(last_tmp, last);
		}
	}

	if (logdir && fp != NULL)
		fclose(fp);

	for (i = 0; i < ndev; i++) {
		if (ci[i].fd != -1) {
			pthread_mutex_destroy(&ci[i].l);
			free(ci[i].cd[0]);
			free(ci[i].cd[1]);
			tcsetattr(ci[i].fd, TCSANOW, &ci[i].tio);
			close(ci[i].fd);
		}
		//free(dev[i]);
	}

	free(last_tmp);
	free(last);
	free(log);
	free(ci);
	free(cd);

	return EXIT_SUCCESS;
}
