#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
int
main(int ac, char **av)
{
	char *prog = av[0];
	if (ac < 2)
		return 1;
	if (setpgid(0, 0) < 0) {
		fprintf(stderr, "%s:setpgid:%s\n", prog, strerror(errno));
		return 1;
	}
	execvp(av[1], av+1); 
	fprintf(stderr, "%s:exec:%s\n", prog, strerror(errno));
	return 1;
}
