#!/bin/sh
# bmc-push.sh: Push kernel/initrd/param/sig to Bitbucket

# Copyright(C): National Institute of Advanced Industrial Science and Technology 2016
# Authors:     
#               Hidetaka Koie <koie-hidetaka@aist.go.jp>
#               Kuniyasu Suzaki <k.suzaki@aist.go.jp>
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

set -eu

PROG="$0"
HG=hg
WGET=wget
LOGFILE="./bmc-push.$$.log"
TMPREPO="./bmc-push.$$.d"

trap atexit 0
atexit()
{
	rm -f "$LOGFILE"
	rm -rf "$TMPREPO"
}

EMSG()
{
	echo "ERROR: $*" 1>&2
}

USAGE()
{
	echo "\
Usage: $PROG -k KERNEL_FILE -i INITRD_FILE [-p 'KERNEL_PARAMS'] [-s SIGN_FILE] [-c] USER/REPO
Options:
 -k FILE        specify a kernel file
 -i FILE        specify a initrd file
 -p STR         specify kernel parameters
 -s FILE        specify a sign of kernel file
 -c             don't create the repository
example: $PROG -k vmlinux -i initrd.img -p 'aaa=bbb xxx=yyy' -s vmlinux.sig alice/test
how to sign:
  openssl cms -sign -binary -noattr -in INITRD -signer CERT -inkey PRIVATE_KEY -certfile CA_CERT -outform DER -out INITRD_SIG
"
}

OPT_KERNEL=""
OPT_INITRD=""
OPT_PARAMS=""
OPT_SIGN=""
OPT_CREATE="true"
while getopts 'hk:i:p:s:c' OPT; do
	case "$OPT" in
	h)	USAGE; exit 0;;
	k)	OPT_KERNEL="$OPTARG";;
	i)	OPT_INITRD="$OPTARG";;
	p)	OPT_PARAMS="$OPTARG";;
	s)	OPT_SIGN="$OPTARG";;
	c)	OPT_CREATE="false";;
	*)	USAGE; exit 1;;
	esac
done
shift $((OPTIND - 1))
[ -n "${OPT_KERNEL:+SET}" ] || { EMSG "-k is not specified"; USAGE; exit 1; }
[ -n "${OPT_INITRD:+SET}" ] || { EMSG "-i is not specified"; USAGE; exit 1; }
[ -r "$OPT_KERNEL" ] || { EMSG "cannot read $OPT_KERNEL"; exit 1; }
[ -r "$OPT_INITRD" ] || { EMSG "cannot read $OPT_INITRD"; exit 1; }
[ -z "$OPT_SIGN" -o -r "$OPT_SIGN" ] || { EMSG "cannot read $OPT_SIGN"; exit 1; }
[ $# -eq 1 ] || { EMSG "USER/REPO is not specified"; USAGE; exit 1; }
URI="$1"; shift
USER="${URI%%/*}"
REPO="${URI#*/}"

if "$OPT_CREATE"; then
	echo "NOTE: Enter password for $USER on Bitbucket"
	$WGET --output-document="$LOGFILE" \
		--user="$USER" --ask-password \
		--header "Content-Type: application/json" \
		--post-data '{"scm": "hg", "is_private": "true", "fork_policy": "no_public_forks" }' \
		"https://api.bitbucket.org/2.0/repositories/$USER/$REPO" || {
			EMSG "Cannot create repository $USER/$REPO"
			cat $LOGFILE
			exit 1
	}
	#jq . "$LOGFILE" # format json
fi

echo "NOTE: Enter passphrase for the ssh key"
$HG clone "ssh://hg@bitbucket.org/$USER/$REPO" "$TMPREPO"
cp "$OPT_KERNEL" "$TMPREPO/my.kernel"
cp "$OPT_INITRD" "$TMPREPO/my.initrd"
if [ -n "$OPT_PARAMS" ]; then
	echo "$OPT_PARAMS" >"$TMPREPO/my.param"
fi
if [ -n "$OPT_SIGN" ]; then
	cp "$OPT_SIGN" "$TMPREPO/my.kernel.sig"
fi
(cd "$TMPREPO" && $HG commit --addremove --message "init" && $HG push)

exit 0
