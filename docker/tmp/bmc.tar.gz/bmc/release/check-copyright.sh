#!/bin/sh
R=$(hg root)
cd "$R"
hg locate | while read F; do
    grep -l 'Copyright(C): National Institute of Advanced Industrial Science and Technology' "$F" >/dev/null 2>&1
    case "$?" in
    0) echo "C $F";;
    1) echo "  $F";;
    *) echo "! $F";;
    esac
done
