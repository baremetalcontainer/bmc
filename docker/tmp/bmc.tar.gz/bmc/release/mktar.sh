#!/bin/sh
set -eux


mktarball() {
	local rev="$1"; shift
	local base="$1"; shift

	local tgz="$base.tar.gz"

	# cleanup
	rm -rf "$tgz" "$base"

	# extract
	hg archive --rev "$rev" --type files "$base"

	# remove non-public files
	rm "$base/.hg_archival.txt"
	./list-public.sh | sed "s|^|$base/|" | xargs rm

	# remove empty directories
	find "$base" -depth -type d -print | xargs rmdir 2>/dev/null || true

	eval "$@"

	tar czf "$tgz" "$base"
	rm -rf "$base"
	ls -lrt "$tgz"
}

rev=$(hg log -r. -l1 --template '{node|short}')
base="bmc-$rev"

mktarball "$rev" "bmc"
mktarball "$rev" "$base" mkdir -p $base/docker/tmp \; cp bmc.tar.gz $base/docker/tmp/bmc.tar.gz
