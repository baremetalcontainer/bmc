#!/bin/sh
set -eu
#set -x

tmpfiles=""
trap cleanup 0
cleanup() {
    rm -f $tmpfiles
}

maketemp() {
    local fn
    fn=$(mktemp /tmp/filter.XXXXXXXX)
    tmpfiles="$tmpfiles $fn"
    echo "$fn"
}

tmp1=$(maketemp)	#repo
tmp2=$(maketemp)	#list
tmp4=$(maketemp)	#not listed

topdir="${1-}"

#echo "---unlisted files---"
if [ -n "$topdir" ]; then
    (cd "$topdir" && find . -type f -print) | sed '/^[.]$/d;s|^[.]/||' | sort >"$tmp1"
else
    hg locate | sort >"$tmp1"
fi
cut -d'	' -f2 files.txt | sort >"$tmp2"
comm -23 "$tmp1" "$tmp2" >"$tmp4"
if [ $(wc -l <"$tmp4") -gt 0 ]; then
    echo "ERROR: unlisted files exist" >&2
    cat "$tmp4"
    exit 1
fi

awk -F'\t' '$1!~/public/ {print $2}' files.txt
